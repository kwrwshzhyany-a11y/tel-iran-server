'use strict';
const express = require('express'), http = require('http'), path = require('path'), crypto = require('crypto');
const { WebSocketServer } = require('ws'), Database = require('better-sqlite3');

const PORT = +process.env.PORT || 3000;
const db = new Database(process.env.DB_FILE || 'teliran.db');
db.exec(`CREATE TABLE IF NOT EXISTS accounts(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL, nick TEXT NOT NULL, created_at INTEGER);
CREATE TABLE IF NOT EXISTS docs(id INTEGER PRIMARY KEY AUTOINCREMENT, col TEXT, data TEXT, ts INTEGER);
CREATE INDEX IF NOT EXISTS docs_col ON docs(col, ts);`);

// ---------- HTTP: serve the app + AI bot endpoint ----------
const app = express();
app.use(express.static(path.join(__dirname, 'public')));

const sessions = new Map();
const hash = s => crypto.createHash('sha256').update(String(s)).digest('hex');
app.use(express.json({limit:'32kb'}));
app.post('/api/auth/signup',(req,res)=>{
  const username=String(req.body.username||'').trim().toLowerCase(), password=String(req.body.password||''), nick=String(req.body.nick||'').trim().slice(0,40)||username;
  if(!/^[a-z0-9_]{5,24}$/.test(username)||password.length<5) return res.status(400).json({error:'username_5_24_and_password_5'});
  try{const r=db.prepare('INSERT INTO accounts(username,password,nick,created_at) VALUES(?,?,?,?)').run(username,hash(password),nick,Date.now()); const token=crypto.randomBytes(24).toString('hex'); sessions.set(token,{id:Number(r.lastInsertRowid),username,nick}); res.json({token,id:Number(r.lastInsertRowid),username,nick});}catch(e){res.status(409).json({error:'username_taken'})}
});
app.post('/api/auth/login',(req,res)=>{const username=String(req.body.username||'').trim().toLowerCase(),password=String(req.body.password||'');const a=db.prepare('SELECT * FROM accounts WHERE username=? AND password=?').get(username,hash(password));if(!a)return res.status(401).json({error:'bad_login'});const token=crypto.randomBytes(24).toString('hex');sessions.set(token,{id:a.id,username:a.username,nick:a.nick});res.json({token,id:a.id,username:a.username,nick:a.nick});});
app.get('/api/auth/me',(req,res)=>{const a=sessions.get(String(req.headers.authorization||'').replace(/^Bearer /,''));if(!a)return res.status(401).end();res.json(a)});
// Real AI replies for the in-app bots, using your own Anthropic API key.
// Without ANTHROPIC_API_KEY set, this endpoint just tells the client
// "not configured" and the bots fall back to a plain message.
const aiHits = new Map();
app.post('/api/ai', express.json({ limit: '8kb' }), async (req, res) => {
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return res.status(501).json({ error: 'not_configured' });
  const ip = req.ip || 'x';
  const now = Date.now(), hist = (aiHits.get(ip) || []).filter(t => now - t < 60e3);
  if (hist.length >= 20) return res.status(429).json({ error: 'too_many' });
  hist.push(now); aiHits.set(ip, hist);

  const persona = String(req.body.persona || '').slice(0, 600);
  const history = String(req.body.history || '').slice(0, 4000);
  if (!persona) return res.status(400).json({ error: 'bad_request' });

  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 300,
        messages: [{ role: 'user', content: persona + ' Reply in the same language as the last user message (Persian, Arabic or English), briefly.\nConversation so far:\n' + history + '\nBot:' }]
      })
    });
    if (!r.ok) { console.error('anthropic error', r.status, await r.text()); return res.status(502).json({ error: 'upstream_failed' }); }
    const j = await r.json();
    const text = (j.content || []).filter(b => b.type === 'text').map(b => b.text).join('').trim();
    res.json({ text: text.slice(0, 1500) });
  } catch (e) { console.error(e); res.status(502).json({ error: 'upstream_failed' }); }
});

const server = http.createServer(app);

// ---------- realtime relay (no accounts) ----------
// Anyone who opens the page can read and post. Identity (name/id) is
// whatever the client sends — there is no login, so do not rely on this
// for anything sensitive. Meant for open, casual chat between friends.
const COLS = { msgs: { max: 100 }, groups: { max: 50 } };
const wss = new WebSocketServer({ server, path: '/ws', maxPayload: 600 * 1024 });

const win = (col, n) => db.prepare('SELECT id,data FROM docs WHERE col=? ORDER BY ts DESC LIMIT ?').all(col, n)
  .map(r => ({ id: String(r.id), data: JSON.parse(r.data) }));
const push = (ws, sid, col, n) => ws.readyState === 1 && ws.send(JSON.stringify({ sid, docs: win(col, n) }));

function clean(col, d) {
  const s = (v, n) => typeof v === 'string' ? v.slice(0, n) : '';
  const u = s(d.u, 40) || 'anon', n = s(d.n, 24) || '?';
  if (col === 'groups') { const gn = s(d.n, 30).trim(); return gn ? { n: gn, by: u, solo: !!d.solo } : null; }
  const o = { t: s(d.t, 500), g: s(d.g, 60), rp: s(d.rp, 80), u, n };
  if (typeof d.exp === 'number') o.exp = d.exp;
  if (typeof d.img === 'string' && /^data:image\/(jpeg|png|webp);base64,/.test(d.img) && d.img.length < 250000) o.img = d.img;
  if (typeof d.aud === 'string' && /^data:audio\//.test(d.aud) && d.aud.length < 400000) o.aud = d.aud;
  if (!o.t && !o.img && !o.aud) return null;
  return o;
}

let inserts = 0;
wss.on('connection', (ws, req) => {
  const token = new URL(req.url, 'http://localhost').searchParams.get('token');
  const account = sessions.get(token);
  if (!account) return ws.close(1008, 'login required');
  ws.account = account; ws.subs = new Map(); ws.rate = []; ws.cid = String(account.id);
  ws.on('close', () => {
    const out = JSON.stringify({ leave: true, from: ws.cid });
    for (const c of wss.clients) if (c !== ws && c.readyState === 1) c.send(out);
  });
  ws.on('message', raw => {
    let m; try { m = JSON.parse(raw); } catch (e) { return; }
    // ephemeral: presence/typing and WebRTC call signaling are relayed live,
    // never stored — same idea as the platform's "room" capability.
    if (m.op === 'presence' || m.op === 'signal') {
      const out = JSON.stringify({ [m.op === 'presence' ? 'presence' : 'signal']: true, from: ws.cid, data: m.data });
      for (const c of wss.clients) if (c !== ws && c.readyState === 1) c.send(out);
      return;
    }
    if (m.op === 'unsub') return void ws.subs.delete(m.sid);
    if (!COLS[m.col]) return;
    if (m.op === 'sub') {
      const n = Math.min(+m.limit || 100, COLS[m.col].max);
      ws.subs.set(m.sid, { col: m.col, n }); push(ws, m.sid, m.col, n);
    } else if (m.op === 'add') {
      const now = Date.now();
      ws.rate = ws.rate.filter(t => now - t < 10e3);
      if (ws.rate.length >= 20) return;
      ws.rate.push(now);
      const d = clean(m.col, Object.assign({}, m.data || {}, {u:ws.account.username,n:ws.account.nick}));
      if (!d) return;
      d.ts = now;
      db.prepare('INSERT INTO docs(col,data,ts) VALUES(?,?,?)').run(m.col, JSON.stringify(d), now);
      if (++inserts % 200 === 0)
        db.prepare('DELETE FROM docs WHERE col=? AND id NOT IN (SELECT id FROM docs WHERE col=? ORDER BY ts DESC LIMIT 20000)').run(m.col, m.col);
      for (const c of wss.clients) for (const [sid, sub] of c.subs) if (sub.col === m.col) push(c, sid, sub.col, sub.n);
    }
  });
});

server.listen(PORT, () => console.log('Tel Iran (open server) running on http://localhost:' + PORT));
